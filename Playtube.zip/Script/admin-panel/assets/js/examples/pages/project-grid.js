$(function () {
    $('.single-datepicker').daterangepicker({
        opens: 'left'
    });

    $('.select2').select2({
        placeholder: 'Select'
    });
});
